/* SPDX-License-Identifier: GPL-2.0 */
#ifndef _KEYS_CEPH_TYPE_H
#define _KEYS_CEPH_TYPE_H

#include <linux/key.h>

extern struct key_type key_type_ceph;

#endif
