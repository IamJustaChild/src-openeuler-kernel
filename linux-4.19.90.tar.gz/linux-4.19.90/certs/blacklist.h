#include <linux/kernel.h>

extern const char __initconst *const blacklist_hashes[];
